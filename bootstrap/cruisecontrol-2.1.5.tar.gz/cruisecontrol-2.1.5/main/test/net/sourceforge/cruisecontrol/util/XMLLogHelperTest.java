/********************************************************************************
 * CruiseControl, a Continuous Integration Toolkit
 * Copyright (c) 2001, ThoughtWorks, Inc.
 * 651 W Washington Ave. Suite 600
 * Chicago, IL 60661 USA
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *     + Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *     + Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *
 *     + Neither the name of ThoughtWorks, Inc., CruiseControl, nor the
 *       names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior
 *       written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ********************************************************************************/
package net.sourceforge.cruisecontrol.util;

import junit.framework.TestCase;
import net.sourceforge.cruisecontrol.CruiseControlException;
import net.sourceforge.cruisecontrol.Modification;
import org.jdom.Element;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.Date;
import java.text.SimpleDateFormat;

public class XMLLogHelperTest extends TestCase {

    private Element successfulLogElement;
    private Element failedLogElement;
    private Date date = new Date();

    public XMLLogHelperTest(String name) {
        super(name);
    }

    private Modification[] createModifications(
        String username1,
        String username2) {
        Modification[] mods = new Modification[3];
        mods[0] = createModification(username1, false);
        mods[1] = createModification(username2, false);
        mods[2] = createModification("user3", true);
        return mods;
    }

    private Modification createModification(String name, boolean addemail) {
        Modification mod = new Modification();
        mod.userName = name;
        mod.comment = "This is the checkin for " + name;
        if (addemail) {
            mod.emailAddress = name + "@host.com";
        }

        mod.fileName = "file.txt";
        mod.folderName = "myfolder";
        mod.modifiedTime = date;
        mod.type = "checkin";
        return mod;
    }

    private Element createModificationsElement(
        String username1,
        String username2) {
        Element modificationsElement = new Element("modifications");
        Modification[] mods = createModifications(username1, username2);
        modificationsElement.addContent(
            mods[0].toElement(new SimpleDateFormat("yyyyMMddHHmmss")));
        modificationsElement.addContent(
            mods[1].toElement(new SimpleDateFormat("yyyyMMddHHmmss")));
        modificationsElement.addContent(
            mods[2].toElement(new SimpleDateFormat("yyyyMMddHHmmss")));
        return modificationsElement;
    }

    private Element createBuildElement(boolean successful) {
        Element buildElement = new Element("build");
        if (!successful) {
            buildElement.setAttribute("error", "No Build Necessary");
        }
        return buildElement;
    }

    private Element createInfoElement(String label, boolean lastSuccessful) {
        Element infoElement = new Element("info");

        Hashtable properties = new Hashtable();
        properties.put("projectname", "someproject");
        properties.put("label", label);
        properties.put("lastbuildtime", "");
        properties.put("lastgoodbuildtime", "");
        properties.put("lastbuildsuccessful", lastSuccessful + "");
        properties.put("buildfile", "");
        properties.put("target", "");
        properties.put("logfile", "log20020313120000.xml");

        Iterator propertyIterator = properties.keySet().iterator();
        while (propertyIterator.hasNext()) {
            String propertyName = (String) propertyIterator.next();
            Element propertyElement = new Element("property");
            propertyElement.setAttribute("name", propertyName);
            propertyElement.setAttribute(
                "value",
                (String) properties.get(propertyName));
            infoElement.addContent(propertyElement);
        }

        return infoElement;
    }

    public void setUp() {
        successfulLogElement = new Element("cruisecontrol");
        successfulLogElement.addContent(createInfoElement("1.0", false));
        successfulLogElement.addContent(createBuildElement(true));
        successfulLogElement.addContent(
            createModificationsElement("username1", "username2"));

        failedLogElement = new Element("cruisecontrol");
        failedLogElement.addContent(createInfoElement("1.1", true));
        failedLogElement.addContent(createBuildElement(false));
        failedLogElement.addContent(
            createModificationsElement("username3", "username4"));
    }

    public void testGetLabel() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        XMLLogHelper failureHelper = new XMLLogHelper(failedLogElement);
        try {
            assertEquals("1.0", successHelper.getLabel());
            assertEquals("1.1", failureHelper.getLabel());
        } catch (CruiseControlException e) {
            assertTrue(false);
        }
    }

    public void testGetLogFileName() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        try {
            assertEquals(
                "log20020313120000.xml",
                successHelper.getLogFileName());
        } catch (CruiseControlException e) {
            assertTrue(false);
        }
    }

    public void testWasPreviousBuildSuccessful() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        XMLLogHelper failureHelper = new XMLLogHelper(failedLogElement);
        try {
            assertEquals(false, successHelper.wasPreviousBuildSuccessful());
            assertEquals(true, failureHelper.wasPreviousBuildSuccessful());
        } catch (CruiseControlException e) {
            assertTrue(false);
        }
    }

    public void testGetCruiseControlInfoProperty() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        try {
            assertEquals(
                "1.0",
                successHelper.getCruiseControlInfoProperty("label"));
        } catch (CruiseControlException e) {
            assertTrue(false);
        }
        try {
            successHelper.getCruiseControlInfoProperty("notaproperty");
        } catch (CruiseControlException e) {
            assertEquals("Property: notaproperty not found.", e.getMessage());
        }
    }

    public void testIsBuildNecessary() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        XMLLogHelper failureHelper = new XMLLogHelper(failedLogElement);
        assertEquals(true, successHelper.isBuildNecessary());
        assertEquals(false, failureHelper.isBuildNecessary());
    }

    public void testGetProjectName() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);

        try {
            assertEquals("someproject", successHelper.getProjectName());
        } catch (CruiseControlException e) {
            assertTrue(false);
        }
    }

    public void testIsBuildSuccessful() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        XMLLogHelper failureHelper = new XMLLogHelper(failedLogElement);
        assertEquals(true, successHelper.isBuildSuccessful());
        assertEquals(false, failureHelper.isBuildSuccessful());
    }

    public void testGetBuildParticipants() {
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        Set successHelperParticipants = successHelper.getBuildParticipants();
        assertEquals(true, successHelperParticipants.contains("username1"));
        assertEquals(true, successHelperParticipants.contains("username2"));
        assertEquals(false, successHelperParticipants.contains("notaperson"));
        assertEquals(
            true,
            successHelperParticipants.contains("user3@host.com"));

        //test P4 changelist structure
        Element ccElement = new Element("cruisecontrol");
        Element modsElement = new Element("modifications");
        Element cl1Element = new Element("changelist");
        cl1Element.setAttribute("user", "user1");
        Element cl2Element = new Element("changelist");
        cl2Element.setAttribute("user", "user2");

        modsElement.addContent(cl1Element);
        modsElement.addContent(cl2Element);
        ccElement.addContent(modsElement);

        XMLLogHelper helper = new XMLLogHelper(ccElement);
        Set p4Users = helper.getBuildParticipants();

        assertEquals(true, p4Users.contains("user1"));
        assertEquals(true, p4Users.contains("user2"));
        assertEquals(false, p4Users.contains("notaperson"));
    }

    public void testGetModifications() {
        //NOTE:  There is an issue with dateformat if you convert
        //a date to a string and parse it back to a date the milliseconds will
        //be different.  Therefore the test gets all of the modifications
        //and sets the date on all of them to account for this.
        XMLLogHelper successHelper = new XMLLogHelper(successfulLogElement);
        Set modifications = successHelper.getModifications();
        Modification[] mods = createModifications("username1", "username2");
        boolean found1 = false;
        boolean found2 = false;
        boolean found3 = false;
        for (Iterator iterator = modifications.iterator();
            iterator.hasNext();
            ) {
            Modification modification = (Modification) iterator.next();
            modification.modifiedTime = date;

            //NOTE:  HashSet contains() doesn't work properly therefore
            //there is this horrible assert statement
            if (modification.userName.equals("username1")) {
                found1 = true;
                assertEquals(modification, mods[0]);
            }
            if (modification.userName.equals("username2")) {
                found2 = true;
                assertEquals(modification, mods[1]);
            }
            if (modification.userName.equals("user3")) {
                found3 = true;
                assertEquals(modification, mods[2]);
            }
        }
        assertTrue(
            "1: " + found1 + " 2:" + found2 + " 3:" + found3,
            found1 && found2 && found3);
    }
}
