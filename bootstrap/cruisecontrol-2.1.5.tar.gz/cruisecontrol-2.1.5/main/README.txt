This file release contains the main CruiseControl JAR file, the BuildServlet
WAR file, and documentation.

Unizip this archive to an empty directory. Then read docs/manual/index.html and 
docs/helloWorld/HelloWorld.html to get started.

Happy cruising.
