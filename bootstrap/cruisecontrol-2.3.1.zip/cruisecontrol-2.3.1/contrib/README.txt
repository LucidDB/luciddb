Contibutions to CruiseControl


This directory contains contributions made to the CruiseControl project that
are not considered to be part of the official project. They usually fall
outside the scope of the CruiseControl application, yet may prove useful to
CruiseControl users. These contributions are NOT maintained by the
CruiseControl developers.

These contributions are included here as a service to both CruiseControl users
and the original contributors. These contributions are provided as is, without
any warranty. USE AT YOUR OWN RISK.

Questions regarding the use of any of these contributions may initially be
directed to the CruiseControl user mailing list
(cruisecontrol-user@lists.sourceforge.net). See documentation included in
the contribution for any further support options.